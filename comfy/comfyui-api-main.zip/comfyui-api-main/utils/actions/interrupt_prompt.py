from api.websocket_api import interupt_prompt
def interrupt():
  interupt_prompt()
